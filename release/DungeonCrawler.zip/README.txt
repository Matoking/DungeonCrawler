Dungeon Crawler
===
A thrill-inducing and adrenaline pumping dungeon crawler game coded in Java for Javalabra2015-3. 
Parental guidance is advised and extra caution is recommended to ensure your socks stay firmly on your feet
for the entire duration of the ride.


INSTRUCTIONS
===
Pick up all of the five keys to win. You can also lose by getting yourself killed by the murderous skeletons if that's more to your liking.
You can attack enemies by moving to their direction while next to them. You can pick up keys and apples in the same way.


CONTROLS
===
Arrow keys to move, pickup items and attack enemies. R restarts the game.